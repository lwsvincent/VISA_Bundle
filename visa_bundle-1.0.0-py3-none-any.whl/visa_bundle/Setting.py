if "VISA_Send_Enable" not in locals():

    # 是否要送出VISA指令
    VISA_Send_Enable: bool = False

    # 是否要列印VISA指令
    VISA_Print_Enable: bool = False

    ITEM_DEBUG: bool = False
    
    IS_SERVER: bool = False
    
    IS_INTERRUPT: bool = False
